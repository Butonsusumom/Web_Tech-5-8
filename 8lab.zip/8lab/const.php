<?php
    define("HOST", "localhost");
    define("USER", "root");
    define("PASS", "Blumblum1@");
    define("DB", "guitar");
    define("DB-TABLE", "news");
?>